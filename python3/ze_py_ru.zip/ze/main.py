import os
import time
import json
import struct
import logging
from collections import defaultdict
from datetime import datetime
import signal

# Глобальный флаг для обработки прерывания
interrupted = False

def signal_handler(sig, frame):
    global interrupted
    interrupted = True
    logger.info("Получен сигнал прерывания, завершаем работу...")

signal.signal(signal.SIGINT, signal_handler)

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('processor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def load_config():
    """Загрузка конфигурации"""
    try:
        with open("config.json", "r") as f:
            config = json.load(f)
        
        required_params = [
            "CrumbSize", "ChunkSize", "CounterValue", 
            "PredictIncrement", "Increment", "ActualizationValue",
            "FiltrationValue", "InputFiles", "OutputFolder", "MatchSuffix"
        ]
        
        for param in required_params:
            if param not in config:
                raise ValueError(f"Отсутствует обязательный параметр: {param}")
        
        logger.info("Конфигурация успешно загружена")
        return config
    
    except Exception as e:
        logger.error(f"Ошибка загрузки конфигурации: {str(e)}")
        raise

try:
    config = load_config()
except Exception as e:
    logger.critical("Невозможно продолжить без конфигурации")
    exit(1)

# Параметры из конфига
CRUMB_SIZE = config["CrumbSize"]
CHUNK_SIZE = config["ChunkSize"]
COUNTER_THRESHOLD = config["CounterValue"]
PREDICT_INCREMENT = config["PredictIncrement"]
INCREMENT = config["Increment"]
ACTUALIZATION_RATIO = config["ActualizationValue"]
FILTRATION_RATIO = config["FiltrationValue"]
INPUT_FILES = config["InputFiles"]
OUTPUT_FOLDER = config["OutputFolder"]
MATCH_SUFFIX = config["MatchSuffix"]

# Инициализация глобальных счетчиков
total_crumbs = 0
total_matches = 0

def split_crumbs(chunk, reverse=False):
    """Разделение чанка на Crumb'ы с возможностью обратного порядка"""
    processor = "inverse" if reverse else "beginning"
    
    # Дополнение нулями если нужно
    padding = (CRUMB_SIZE - len(chunk) % CRUMB_SIZE) % CRUMB_SIZE
    if padding:
        padded = chunk + b"\x00" * padding
    else:
        padded = chunk

    crumbs = []
    if reverse:
        # Обработка с конца
        for i in range(len(padded)-CRUMB_SIZE, -CRUMB_SIZE, -CRUMB_SIZE):
            if i < 0:
                crumb = padded[0:CRUMB_SIZE]
            else:
                crumb = padded[i:i+CRUMB_SIZE]
            value = int.from_bytes(crumb, byteorder='big')
            crumbs.append(value)
    else:
        # Обычная обработка с начала
        for i in range(0, len(padded), CRUMB_SIZE):
            crumb = padded[i:i + CRUMB_SIZE]
            value = int.from_bytes(crumb, byteorder='big')
            crumbs.append(value)
    
    return crumbs

def save_state(file_path, data_dict):
    """Сохранение состояния в бинарный файл"""
    try:
        os.makedirs(os.path.dirname(file_path) or '.', exist_ok=True)
        
        with open(file_path, "wb") as f:
            for k, v in data_dict.items():
                f.write(struct.pack(">II", k, v))
        
        logger.info(f"Сохранено состояние в {file_path} ({len(data_dict)} записей)")
    except Exception as e:
        logger.error(f"Ошибка сохранения {file_path}: {str(e)}")
        raise

def threshold_check(counters):
    """Проверка и сброс счетчиков при достижении порога"""
    if any(v >= COUNTER_THRESHOLD for v in counters.values()):
        for k in list(counters.keys()):
            counters[k] //= 2
        return True
    return False

def process_crumb_optimized(counters, crumb, processor_name):
    """Оптимизированная обработка Crumb с уменьшенной частотой фильтрации"""
    global total_matches, total_crumbs
    
    total_crumbs += 1
    
    # Проверка прерывания
    if interrupted:
        raise KeyboardInterrupt("Обработка прервана пользователем")
    
    # Проверка сброса
    threshold_check(counters)
    
    # Оптимизированная проверка совпадений
    if crumb in counters:
        total_matches += 1
        # Увеличиваем счетчик без полной сортировки
        counters[crumb] += PREDICT_INCREMENT if counters[crumb] > COUNTER_THRESHOLD//2 else INCREMENT
    else:
        counters[crumb] = INCREMENT

    # Фильтрация выполняется реже и только при значительном росте счетчиков
    if total_crumbs % 10000 == 0 and len(counters) > 1000:
        filter_counters(counters, processor_name)

def filter_counters(counters, processor_name):
    """Оптимизированная фильтрация счетчиков"""
    if not counters:
        return
    
    # Быстрая фильтрация без полной сортировки
    threshold = sorted(counters.values())[-int(len(counters)*FILTRATION_RATIO)]
    to_remove = [k for k, v in counters.items() if v <= threshold]
    
    for k in to_remove:
        del counters[k]
    
    logger.info(f"[{processor_name}] Фильтрация: удалено {len(to_remove)} счетчиков (осталось {len(counters)})")

def read_chunks_optimized(file_path):
    """Оптимизированное чтение файла"""
    try:
        if not os.path.exists(file_path):
            logger.warning(f"Файл не найден: {file_path}")
            return

        file_size = os.path.getsize(file_path)
        logger.info(f"Обработка файла: {file_path} (размер: {file_size/1024/1024:.2f} MB)")

        with open(file_path, "rb") as f:
            while True:
                if interrupted:
                    raise KeyboardInterrupt()
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break
                yield chunk

    except Exception as e:
        logger.error(f"Ошибка чтения файла: {str(e)}")
        raise

def main_optimized():
    global total_crumbs, total_matches
    
    logger.info("=== Начало обработки ===")
    start_time = datetime.now()
    
    try:
        for file_path in INPUT_FILES:
            if interrupted:
                break
                
            if not os.path.exists(file_path):
                logger.error(f"Файл не найден: {file_path}")
                continue
                
            file_size = os.path.getsize(file_path)
            base = os.path.basename(file_path)
            out_begin = os.path.join(OUTPUT_FOLDER, base.replace(".bin", "_begin.bin"))
            out_inverse = os.path.join(OUTPUT_FOLDER, base.replace(".bin", "_inverse.bin"))
            out_match = os.path.join(OUTPUT_FOLDER, base.replace(".bin", MATCH_SUFFIX))

            counters_beginning = defaultdict(int)
            counters_inverse = defaultdict(int)
            file_crumbs = 0
            last_log_time = time.time()  # Исправлено: используем time.time() вместо datetime.time
            
            with open(file_path, "rb") as f:
                while True:
                    if interrupted:
                        break
                        
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                        
                    # Обработка чанка
                    for crumb in split_crumbs(chunk, reverse=False):
                        process_crumb_optimized(counters_beginning, crumb, "beginning")
                        file_crumbs += 1
                    
                    for crumb in split_crumbs(chunk, reverse=True):
                        process_crumb_optimized(counters_inverse, crumb, "inverse")
                        file_crumbs += 1
                    
                    # Логирование прогресса не чаще чем раз в 5 секунд
                    current_time = time.time()
                    if current_time - last_log_time > 5:
                        progress = f.tell() / file_size * 100
                        logger.info(f"Прогресс: {progress:.1f}%")
                        last_log_time = current_time
            
            if not interrupted:
                save_state(out_begin, counters_beginning)
                save_state(out_inverse, counters_inverse)
                save_state(out_match, {0: total_matches, 1: total_crumbs})
                
                logger.info(f"Файл обработан: {file_path}")
                logger.info(f"  Всего Crumb'ов: {file_crumbs}")
                logger.info(f"  Совпадений: {total_matches}")
    
    except KeyboardInterrupt:
        logger.info("Обработка прервана пользователем")
    except Exception as e:
        logger.error(f"Критическая ошибка: {str(e)}", exc_info=True)
        return 1
    
    duration = datetime.now() - start_time
    logger.info(f"Общее время выполнения: {duration.total_seconds():.2f} сек")
    logger.info(f"Всего обработано Crumb'ов: {total_crumbs}")
    logger.info(f"Всего совпадений: {total_matches}")
    return 0

if __name__ == "__main__":
    exit_code = main_optimized()
    exit(exit_code)